import axios from "axios";
import { prisma } from "../../prisma/client";
import { env } from "../config/env";
import { ApiError } from "../common/errors/ApiError";

function requireHttpsUrl(name: string, value: string) {
  if (!value) throw new ApiError(400, `Missing env: ${name}`);
  if (!/^https?:\/\//i.test(value)) throw new ApiError(400, `${name} must be a valid URL`);
  return value;
}

async function paypalAccessToken() {
  if (!env.PAYPAL_CLIENT_ID || !env.PAYPAL_CLIENT_SECRET) {
    throw new ApiError(400, "PayPal env missing");
  }
  const basic = Buffer.from(`${env.PAYPAL_CLIENT_ID}:${env.PAYPAL_CLIENT_SECRET}`).toString("base64");
  const r = await axios.post(
    `${env.PAYPAL_BASE_URL}/v1/oauth2/token`,
    "grant_type=client_credentials",
    { headers: { Authorization: `Basic ${basic}`, "Content-Type": "application/x-www-form-urlencoded" } }
  );
  return r.data.access_token as string;
}

export async function createMercadoPagoPreference(orderId: string) {
  const order = await prisma.order.findUnique({ where: { id: orderId }, include: { items: { include: { product: true } } } });
  if (!order) throw new ApiError(404, "Order not found");
  if (!env.MP_ACCESS_TOKEN) throw new ApiError(400, "MP env missing");

  // URLs para retorno + webhook
  const notification_url = env.MP_NOTIFICATION_URL ? requireHttpsUrl("MP_NOTIFICATION_URL", env.MP_NOTIFICATION_URL) : undefined;
  const back_urls = {
    success: env.MP_SUCCESS_URL || undefined,
    failure: env.MP_FAILURE_URL || undefined,
    pending: env.MP_PENDING_URL || undefined
  };

  const items = order.items.map(i => ({
    title: i.product.title,
    quantity: i.quantity,
    unit_price: i.unitPrice / 100 // MP espera float en moneda
  }));

  const r = await axios.post(
    "https://api.mercadopago.com/checkout/preferences",
    {
      items,
      external_reference: order.id,
      notification_url,
      back_urls: {
        success: back_urls.success,
        failure: back_urls.failure,
        pending: back_urls.pending
      },
      auto_return: back_urls.success ? "approved" : undefined,
      metadata: {
        orderId: order.id,
        userId: order.userId
      }
    },
    { headers: { Authorization: `Bearer ${env.MP_ACCESS_TOKEN}` } }
  );

  await prisma.order.update({ where: { id: orderId }, data: { providerRef: String(r.data.id) } });
  return { init_point: r.data.init_point, preferenceId: String(r.data.id) };
}

/**
 * Mercado Pago subscription (Preapproval) para AR.
 * Crea una suscripción recurrente mensual por el precio del producto.
 */
export async function mercadoPagoCreateSubscription(userId: string, productId: string, returnUrl?: string, cancelUrl?: string) {
  if (!env.MP_ACCESS_TOKEN) throw new ApiError(400, "MP env missing");
  const notification_url = env.MP_NOTIFICATION_URL ? requireHttpsUrl("MP_NOTIFICATION_URL", env.MP_NOTIFICATION_URL) : undefined;

  const product = await prisma.product.findUnique({ where: { id: productId } });
  if (!product) throw new ApiError(404, "Product not found");
  if (!product.isSubscription) throw new ApiError(400, "Product is not subscription");

  const backUrl = returnUrl || env.MP_SUCCESS_URL || "";
  if (!backUrl) throw new ApiError(400, "Missing returnUrl (body.returnUrl or MP_SUCCESS_URL)");

  // Preapproval: mensual, ARS
  const body = {
    reason: product.title,
    external_reference: `${userId}:${productId}`,
    back_url: backUrl,
    notification_url,
    auto_recurring: {
      frequency: 1,
      frequency_type: "months",
      transaction_amount: product.price / 100,
      currency_id: "ARS"
    },
    metadata: {
      userId,
      productId
    }
  };

  const r = await axios.post("https://api.mercadopago.com/preapproval", body, {
    headers: { Authorization: `Bearer ${env.MP_ACCESS_TOKEN}` }
  });

  // Guardamos placeholder para tener mapping inmediato
  await prisma.subscription.upsert({
    where: { userId },
    create: { userId, provider: "MERCADOPAGO", status: "PAST_DUE", externalId: String(r.data.id), cancelAtPeriodEnd: false },
    update: { provider: "MERCADOPAGO", externalId: String(r.data.id) }
  });

  return { init_point: r.data.init_point, preapprovalId: String(r.data.id) };
}

export async function paypalCreateCheckout(orderId: string, returnUrl: string, cancelUrl: string) {
  const order = await prisma.order.findUnique({ where: { id: orderId }, include: { items: { include: { product: true } } } });
  if (!order) throw new ApiError(404, "Order not found");

  const token = await paypalAccessToken();

  const purchase_units = [{
    reference_id: order.id,
    invoice_id: order.id,
    amount: {
      currency_code: order.currency,
      value: (order.totalAmount / 100).toFixed(2)
    }
  }];

  const r = await axios.post(
    `${env.PAYPAL_BASE_URL}/v2/checkout/orders`,
    {
      intent: "CAPTURE",
      purchase_units,
      application_context: { return_url: returnUrl, cancel_url: cancelUrl }
    },
    { headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" } }
  );

  const approve = r.data.links?.find((l: any) => l.rel === "approve")?.href;
  await prisma.order.update({ where: { id: orderId }, data: { providerRef: String(r.data.id) } });

  return { id: r.data.id, approveUrl: approve };
}

export async function paypalCaptureCheckout(userId: string, paypalOrderId: string) {
  const order = await prisma.order.findFirst({ where: { provider: "PAYPAL", providerRef: paypalOrderId, userId } });
  if (!order) throw new ApiError(404, "Order not found for this user");

  const token = await paypalAccessToken();

  const r = await axios.post(
    `${env.PAYPAL_BASE_URL}/v2/checkout/orders/${paypalOrderId}/capture`,
    {},
    { headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" } }
  );

  // Si captura OK, marcamos pagada (idempotente via status)
  if (order.status !== "PAID") {
    const captureId = r.data?.purchase_units?.[0]?.payments?.captures?.[0]?.id ?? paypalOrderId;
    // marcamos paid y generamos accessGrants
    const { markPaid } = await import("./orders.service");
    await markPaid(order.id, String(captureId), r.data);
  }

  return { status: r.data.status, raw: r.data };
}

export async function paypalCreateSubscription(userId: string, productId: string, returnUrl: string, cancelUrl: string) {
  const product = await prisma.product.findUnique({ where: { id: productId } });
  if (!product) throw new ApiError(404, "Product not found");
  if (!product.isSubscription) throw new ApiError(400, "Product is not subscription");
  if (!product.paypalPlanId) throw new ApiError(400, "Missing paypalPlanId in product");

  const token = await paypalAccessToken();

  const r = await axios.post(
    `${env.PAYPAL_BASE_URL}/v1/billing/subscriptions`,
    {
      plan_id: product.paypalPlanId,
      custom_id: `${userId}:${productId}`,
      application_context: { return_url: returnUrl, cancel_url: cancelUrl }
    },
    { headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" } }
  );

  const approve = r.data.links?.find((l: any) => l.rel === "approve")?.href;

  // Guardamos placeholder para mapear al usuario incluso si el webhook llega tarde
  await prisma.subscription.upsert({
    where: { userId },
    create: { userId, provider: "PAYPAL", status: "PAST_DUE", externalId: String(r.data.id), cancelAtPeriodEnd: false },
    update: { provider: "PAYPAL", externalId: String(r.data.id) }
  });

  return { id: r.data.id, approveUrl: approve };
}